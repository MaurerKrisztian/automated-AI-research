"""Fixed-budget errors and a per-(head, chunk) switch:
use the exact-chunk preconditioner when sqrt(a_1/a_C) <= THR, else MesaNet CG."""
import numpy as np, json, sys
from mesa_exact import nested_solve
import mesa_pcg as mp

mp.rng = np.random.default_rng(7)
THR = 2.5
KS = [0, 1, 2, 3, 5, 10, 30]


def at(errs, k):
    return errs[min(k, len(errs) - 1)]


def run(d, C, T0, gm, lam, trials=4):
    rec = {"cg": [], "ours": [], "hyb": [], "its_cg": [], "its_hyb": [], "its_ours": []}
    for _ in range(trials):
        I = mp.build_instance(d, C, T0, gm, lam)
        Ms, Q, a = I["Ms"], I["Q"], I["a"]
        diag = np.einsum('tii->ti', Ms)
        e_cg = mp.pcg(Ms, Q, Q / diag, lambda R: R)
        abar = np.sqrt(a[0] * a[-1])
        B = I["H0"] + (lam / abar) * np.eye(d)
        Kh = I["K"] * np.sqrt(I["b"] / a)[:, None]
        prec = lambda R: nested_solve(B, Kh, R) / a[:, None]
        e_o = mp.pcg(Ms, Q, prec(Q), prec)
        use_ours = np.sqrt(a[0] / a[-1]) <= THR
        e_h = e_o if use_ours else e_cg
        for name, e in (("cg", e_cg), ("ours", e_o), ("hyb", e_h)):
            rec[name].append([at(e, k) for k in KS])
        for name, e in (("its_cg", e_cg), ("its_hyb", e_h), ("its_ours", e_o)):
            x = mp.iters_to(e, 1e-4); rec[name].append(100 if x is None else x)
    return {k: (np.max(np.array(v), axis=0).tolist() if not k.startswith("its") else int(max(v)))
            for k, v in rec.items()}


if __name__ == "__main__":
    d, T0 = 128, 2048
    out = []
    for C in (16, 64):
        for gm in (0.999, 0.99, 0.95, 0.9, 0.8, 0.5):
            r = run(d, C, T0, gm, 0.25)
            r.update(C=C, gamma=gm)
            out.append(r)
            print(json.dumps({"C": C, "gamma": gm, "its@1e-4 cg/ours/hyb": (r["its_cg"], r["its_ours"], r["its_hyb"]),
                              "cg err k=10,30": (f"{r['cg'][5]:.1e}", f"{r['cg'][6]:.1e}"),
                              "hyb err k=1,2,3": (f"{r['hyb'][1]:.1e}", f"{r['hyb'][2]:.1e}", f"{r['hyb'][3]:.1e}")}))
            sys.stdout.flush()
    json.dump(out, open("hybrid_results.json", "w"), indent=1)
