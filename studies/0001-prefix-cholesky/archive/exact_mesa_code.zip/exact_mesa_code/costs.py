"""Analytic flops per token per head (d_k = d_v = d) and an fp32 stress test."""
import numpy as np
import mesa_pcg as mp
from mesa_exact import nested_solve


def gla(d, dv, C):          # chunkwise linear-attention readout + G update
    return 4 * d * dv + 2 * C * d + 2 * C * dv

def gdn(d, dv, C):          # Gated DeltaNet chunkwise (UT transform)
    return 6 * d * dv + 4 * C * d + 4 * C * dv + C * C

def mesanet(d, dv, C, k):   # k CG passes (each an H-matvec pass) + H update + readout
    return k * (2 * d * d + 4 * C * d) + 2 * d * d + gla(d, dv, C)

def setup(d, C):            # chol(B), B^{-1}K^T, A = I + K B^{-1} K^T, chol(A)
    return d ** 3 / (3 * C) + 2 * d * d + 2 * C * d + C * C / 3

def apply_(d, C):           # one exact chunk solve for C right-hand sides
    return 2 * d * d + 4 * C * d + 2 * C * C

def exact(d, dv, C):        # exact variants: one apply + H update + readout
    return setup(d, C) + apply_(d, C) + 2 * d * d + gla(d, dv, C)

def ours_pcg(d, dv, C, k):  # k PCG iterations with the exact-chunk preconditioner
    return setup(d, C) + (k + 1) * apply_(d, C) + k * (2 * d * d + 4 * C * d) + 2 * d * d + gla(d, dv, C)


if __name__ == "__main__":
    d = dv = 128
    for C in (16, 64):
        base = gdn(d, dv, C)
        print(f"--- C={C}, flops/token relative to Gated DeltaNet ({base/1e3:.0f}k) ---")
        print(f"GLA readout only          : {gla(d, dv, C)/base:5.2f}")
        for k in (9, 15, 30):
            print(f"MesaNet CG k={k:2d}           : {mesanet(d, dv, C, k)/base:5.2f}")
        print(f"Exact chunk (one pass)    : {exact(d, dv, C)/base:5.2f}")
        for k in (1, 2, 3):
            print(f"Exact-chunk PCG k={k}       : {ours_pcg(d, dv, C, k)/base:5.2f}")

    print("--- fp32 stress test: gamma=0.999, lam=0.25, 2048-token prefix ---")
    mp.rng = np.random.default_rng(11)
    for C in (16, 64):
        I = mp.build_instance(128, C, 2048, 0.999, 0.25)
        a = I["a"]; abar = np.sqrt(a[0] * a[-1])
        B = I["H0"] + (0.25 / abar) * np.eye(128)
        Kh = I["K"] * np.sqrt(I["b"] / a)[:, None]
        X64 = nested_solve(B, Kh, I["Q"], np.float64)
        X32 = nested_solve(B, Kh, I["Q"], np.float32)
        e = np.max(np.linalg.norm(X32 - X64, axis=1) / np.linalg.norm(X64, axis=1))
        kB = np.linalg.cond(B)
        print(f"C={C}: cond(B)={kB:.1e}  fp32 vs fp64 max rel err = {e:.1e}")
