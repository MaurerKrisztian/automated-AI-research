# Exact chunkwise Mesa attention — sanity-check scripts

Plain numpy + scipy, CPU only. Run each from this folder with `python3 <script>`.

| Script | What it checks | Runtime |
| --- | --- | --- |
| `mesa_exact.py` | The nested-inverse identity (one Cholesky per chunk) vs per-position solves, fp64 and fp32 | seconds |
| `mesa_layers.py` | Full layers across chunks: Mesa-P (gated, period-refreshed ridge) and sliding-window Mesa (signed LDLᵀ) vs token-by-token references | ~1 min |
| `pdn_check.py` | Exactly preconditioned DeltaNet (write keys from the identity) reproduces exact Mesa | seconds |
| `mesa_pcg.py` | MesaNet's fixed-ridge model: MesaNet-style CG vs Jacobi PCG vs exact-chunk-preconditioned CG, iterations to 1e-4 / 1e-6 (writes `pcg_results.json`) | a few min |
| `mesa_hybrid.py` | Same, with the per-(head, chunk) switch and errors at fixed iteration budgets (writes `hybrid_results.json`) | a few min |
| `costs.py` | Analytic flops per token vs Gated DeltaNet, plus an fp32 stress test on a long-memory head | seconds |

Core function: `nested_solve(B, K, Q)` in `mesa_exact.py` returns
x_τ = (B + K[:τ]ᵀ K[:τ])⁻¹ q_τ for every τ in a chunk from one d×d Cholesky,
one C×C Cholesky and two masked triangular solves.

Keys are synthetic (unit norm, anisotropic spectrum, AR(1)-correlated); real
trained keys may be worse conditioned.
