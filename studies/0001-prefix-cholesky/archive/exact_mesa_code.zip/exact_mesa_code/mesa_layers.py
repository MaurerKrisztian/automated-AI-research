"""End-to-end checks of exact chunkwise Mesa variants against per-token references."""
import numpy as np
from scipy.linalg import cho_factor, cho_solve, solve_triangular, cholesky
from mesa_exact import nested_solve, make_keys, gates

rng = np.random.default_rng(1)


# ------------------------------------------------------------------ references
def mesa_reference(keys, vals, qs, beta, gamma, lam, period=None):
    """Per-token reference.  period=None -> MesaNet (fixed ridge lam*I).
    period=P -> 'Mesa-P': ridge decays with the gates inside each period of P
    tokens and is topped back up to lam at period boundaries."""
    T, d = keys.shape
    D = np.zeros((d, d)); G = np.zeros((vals.shape[1], d)); r = lam
    out = np.zeros((T, vals.shape[1]))
    for t in range(T):
        D = gamma[t] * D + beta[t] * np.outer(keys[t], keys[t])
        G = gamma[t] * G + beta[t] * np.outer(vals[t], keys[t])
        if period is None:
            H = D + lam * np.eye(d)
        else:
            r = gamma[t] * r
            H = D + r * np.eye(d)
        out[t] = G @ np.linalg.solve(H, qs[t])
        if period is not None and (t + 1) % period == 0:
            r = lam
    return out


# ------------------------------------------------------- exact chunked Mesa-P
def mesa_P_chunked(keys, vals, qs, beta, gamma, lam, C):
    """Exact chunkwise algorithm for Mesa-P with period P = C."""
    T, d = keys.shape
    H = lam * np.eye(d)            # includes the (refreshed) ridge
    G = np.zeros((vals.shape[1], d))
    out = np.zeros((T, vals.shape[1]))
    for c in range(0, T, C):
        K, V, Qc = keys[c:c + C], vals[c:c + C], qs[c:c + C]
        b, g = beta[c:c + C], gamma[c:c + C]
        a = np.cumprod(g)
        w = b / a
        Kh = K * np.sqrt(w)[:, None]
        X = nested_solve(H, Kh, Qc) / a[:, None]          # q*_tau, all tau at once
        S = np.triu(K @ X.T)                               # S[i,tau] = k_i.x_tau, i<=tau
        O = a[:, None] * (X @ G.T + (w[:, None] * S).T @ V)  # GLA-form readout
        out[c:c + C] = O
        H = a[-1] * (H + Kh.T @ Kh) + lam * (1 - a[-1]) * np.eye(d)   # end state + ridge top-up
        G = a[-1] * (G + (V * w[:, None]).T @ K)
    return out


# --------------------------------------------------- signed nested solve (LDL)
def ldl_nopivot(A):
    n = A.shape[0]
    L = np.eye(n); Dg = np.zeros(n)
    A = A.copy()
    for j in range(n):
        Dg[j] = A[j, j] - (L[j, :j] ** 2) @ Dg[:j]
        for i in range(j + 1, n):
            L[i, j] = (A[i, j] - (L[i, :j] * L[j, :j]) @ Dg[:j]) / Dg[j]
    return L, Dg


def signed_nested_solve(B, U, signs, Q, block=2):
    """x_tau = (B + sum_{rows i < block*tau} s_i u_i u_i^T)^{-1} q_tau."""
    C = Q.shape[0]
    cb = cho_factor(B, lower=True)
    BiUt = cho_solve(cb, U.T)
    BiQt = cho_solve(cb, Q.T)
    A = np.diag(signs) + U @ BiUt
    L, Dg = ldl_nopivot(A)
    Y = U @ BiQt                                  # (block*C) x C
    W = solve_triangular(L, Y, lower=True, unit_diagonal=True)
    rows = np.arange(U.shape[0])[:, None]
    cols = np.arange(C)[None, :]
    W = np.where(rows < block * (cols + 1), W, 0.0) / Dg[:, None]
    Z = solve_triangular(L.T, W, lower=False, unit_diagonal=True)
    return (BiQt - BiUt @ Z).T


def swmesa_reference(keys, vals, qs, beta, lam, Wn):
    T, d = keys.shape
    out = np.zeros((T, vals.shape[1]))
    for t in range(T):
        lo = max(0, t - Wn + 1)
        Kw = keys[lo:t + 1] * np.sqrt(beta[lo:t + 1, None])
        H = lam * np.eye(d) + Kw.T @ Kw
        G = (vals[lo:t + 1] * beta[lo:t + 1, None]).T @ keys[lo:t + 1]
        out[t] = G @ np.linalg.solve(H, qs[t])
    return out


def swmesa_chunked(keys, vals, qs, beta, lam, Wn, C):
    """Exact sliding-window Mesa: add new key, remove key leaving the window."""
    T, d = keys.shape
    pad = np.zeros((Wn, d)); padv = np.zeros((Wn, vals.shape[1]))
    Kp = np.vstack([pad, keys]); Vp = np.vstack([padv, vals]); bp = np.concatenate([np.zeros(Wn), beta])
    H = lam * np.eye(d); G = np.zeros((vals.shape[1], d))
    out = np.zeros((T, vals.shape[1]))
    for c in range(0, T, C):
        n = min(C, T - c)
        idx_in = Wn + c + np.arange(n)            # entering tokens (padded index)
        idx_out = idx_in - Wn                      # leaving tokens
        U = np.zeros((2 * n, d)); s = np.zeros(2 * n)
        U[0::2] = Kp[idx_in] * np.sqrt(bp[idx_in, None]); s[0::2] = 1
        U[1::2] = Kp[idx_out] * np.sqrt(bp[idx_out, None]); s[1::2] = -1
        X = signed_nested_solve(H, U, s, qs[c:c + n])
        # readout: G_tau = G + sum_{i<=tau} b v k^T (in) - b v k^T (out)
        Sin = np.triu(Kp[idx_in] @ X.T) * bp[idx_in, None]
        Sout = np.triu(Kp[idx_out] @ X.T) * bp[idx_out, None]
        out[c:c + n] = X @ G.T + Sin.T @ Vp[idx_in] - Sout.T @ Vp[idx_out]
        H = H + U.T @ (s[:, None] * U)
        G = G + (Vp[idx_in] * bp[idx_in, None]).T @ Kp[idx_in] - (Vp[idx_out] * bp[idx_out, None]).T @ Kp[idx_out]
    return out


def rel(a, b):
    return np.max(np.linalg.norm(a - b, axis=1) / (np.linalg.norm(b, axis=1) + 1e-30))


if __name__ == "__main__":
    d, dv, T = 64, 64, 512
    keys = make_keys(T, d, rng=rng); qs = make_keys(T, d, rng=rng)
    vals = rng.standard_normal((T, dv)); beta = rng.uniform(0.2, 1.0, T)

    print("=== Test 2: exact chunked Mesa-P vs per-token reference (fp64) ===")
    for gm in (1.0, 0.99, 0.95):
        gamma = gates(T, gm, rng=rng)
        for C in (16, 64):
            ref = mesa_reference(keys, vals, qs, beta, gamma, 0.25, period=C)
            got = mesa_P_chunked(keys, vals, qs, beta, gamma, 0.25, C)
            print(f"gamma~{gm:<5} C={C:3d}  max rel err = {rel(got, ref):.2e}")

    print("=== Test 3: exact sliding-window Mesa (signed LDL) vs reference ===")
    for Wn in (32, 128):
        for C in (16, 32):
            ref = swmesa_reference(keys, vals, qs, beta, 0.25, Wn)
            got = swmesa_chunked(keys, vals, qs, beta, 0.25, Wn, C)
            print(f"W={Wn:4d} C={C:3d}  max rel err = {rel(got, ref):.2e}")
