"""MesaNet's exact model (fixed ridge, per-token forget gates):
compare MesaNet-style CG, Jacobi-PCG, and PCG preconditioned by the exact
chunk solver (exact up to a scalar ridge shift)."""
import numpy as np
import json, sys
from mesa_exact import nested_solve, make_keys, gates

rng = np.random.default_rng(2)


def build_instance(d, C, T0, gmean, lam, alpha=1.0, rho=0.6):
    T = T0 + C
    keys = make_keys(T, d, alpha=alpha, rho=rho, rng=rng)
    qs = make_keys(C, d, alpha=alpha, rho=rho, rng=rng)
    beta = rng.uniform(0.2, 1.0, T)
    gamma = gates(T, gmean, rng=rng)
    # data-only state at chunk start
    gp = gamma[:T0]
    zeta = np.concatenate([np.cumprod(gp[::-1])[::-1][1:], [1.0]])  # prod_{j>i} gamma_j
    Kp = keys[:T0] * np.sqrt(zeta * beta[:T0])[:, None]
    H0 = Kp.T @ Kp
    K = keys[T0:]; b = beta[T0:]; g = gamma[T0:]
    a = np.cumprod(g)
    Ms = np.zeros((C, d, d))
    Hd = H0.copy()
    for t in range(C):
        Hd = g[t] * Hd + b[t] * np.outer(K[t], K[t])
        Ms[t] = Hd + lam * np.eye(d)
    return dict(H0=H0, K=K, b=b, a=a, Ms=Ms, Q=qs, lam=lam)


def pcg(Ms, Q, X0, precond, maxit=100):
    """Vectorised PCG over C independent systems; returns iterates' errors."""
    Xstar = np.linalg.solve(Ms, Q[..., None])[..., 0]
    nrm = np.linalg.norm(Xstar, axis=1)
    err = lambda X: np.max(np.linalg.norm(X - Xstar, axis=1) / nrm)
    X = X0.copy()
    R = Q - np.einsum('tij,tj->ti', Ms, X)
    Z = precond(R)
    P = Z.copy()
    rz = np.sum(R * Z, axis=1)
    errs = [err(X)]
    for k in range(maxit):
        AP = np.einsum('tij,tj->ti', Ms, P)
        alpha = rz / np.maximum(np.sum(P * AP, axis=1), 1e-300)
        X = X + alpha[:, None] * P
        R = R - alpha[:, None] * AP
        Z = precond(R)
        rz_new = np.sum(R * Z, axis=1)
        beta = rz_new / np.maximum(rz, 1e-300)
        P = Z + beta[:, None] * P
        rz = rz_new
        errs.append(err(X))
        if errs[-1] < 1e-10:
            break
    return errs


def iters_to(errs, tol):
    for k, e in enumerate(errs):
        if e <= tol:
            return k
    return None


def run_config(d, C, T0, gmean, lam, trials=3):
    out = {"mesanet_cg": [], "jacobi_pcg": [], "exact_chunk_pcg": [], "kappa": [], "bound": []}
    for _ in range(trials):
        I = build_instance(d, C, T0, gmean, lam)
        Ms, Q, a = I["Ms"], I["Q"], I["a"]
        diag = np.einsum('tii->ti', Ms)
        # MesaNet: Jacobi initial guess, plain CG
        e_cg = pcg(Ms, Q, Q / diag, lambda R: R)
        # Jacobi-preconditioned CG
        e_jpcg = pcg(Ms, Q, Q / diag, lambda R: R / diag)
        # exact-chunk preconditioner at reference abar = sqrt(a_1 a_C)
        abar = np.sqrt(a[0] * a[-1])
        B = I["H0"] + (lam / abar) * np.eye(d)
        Kh = I["K"] * np.sqrt(I["b"] / a)[:, None]
        prec = lambda R: nested_solve(B, Kh, R) / a[:, None]
        e_ours = pcg(Ms, Q, prec(Q), prec)
        out["mesanet_cg"].append(e_cg); out["jacobi_pcg"].append(e_jpcg); out["exact_chunk_pcg"].append(e_ours)
        ev = np.linalg.eigvalsh(Ms)
        out["kappa"].append(float(np.median(ev[:, -1] / ev[:, 0])))
        out["bound"].append(float(np.sqrt(a[0] / a[-1])))
    return out


if __name__ == "__main__":
    d, T0 = 128, 2048
    rows = []
    for C in (16, 64):
        for lam in (0.25, 1.0):
            for gm in (0.999, 0.99, 0.95, 0.9, 0.8, 0.5):
                res = run_config(d, C, T0, gm, lam)
                row = {"C": C, "lam": lam, "gamma": gm,
                       "kappa_med": float(np.median(res["kappa"])),
                       "kappa_bound_ours": float(np.max(res["bound"]))}
                for m in ("mesanet_cg", "jacobi_pcg", "exact_chunk_pcg"):
                    for tol in (1e-4, 1e-6):
                        its = [iters_to(e, tol) for e in res[m]]
                        its = [100 if x is None else x for x in its]
                        row[f"{m}@{tol:g}"] = max(its)
                    row[f"{m}_err0"] = float(np.max([e[0] for e in res[m]]))
                rows.append(row)
                print(json.dumps(row)); sys.stdout.flush()
    with open("pcg_results.json", "w") as f:
        json.dump(rows, f, indent=1)
