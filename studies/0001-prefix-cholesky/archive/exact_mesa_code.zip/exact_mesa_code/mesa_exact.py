"""
Exact chunkwise-parallel solver for Mesa / test-time-ridge-regression readouts.

Core lemma ("nested inverse via leading Cholesky blocks"):
  For SPD B (d x d), keys K (C x d), queries Q (C x d), the C solutions
      x_tau = (B + K[:tau]^T K[:tau])^{-1} q_tau ,  tau = 1..C
  are obtained from ONE Cholesky factor L of A = I + K B^{-1} K^T and two
  masked triangular solves, because the Cholesky factor of every leading
  principal block A[:tau,:tau] is L[:tau,:tau].
"""
import numpy as np
from scipy.linalg import cho_factor, cho_solve, solve_triangular, cholesky

rng = np.random.default_rng(0)


# ---------------------------------------------------------------- core lemma
def nested_solve(B, K, Q, dtype=np.float64):
    """x_tau = (B + K[:tau].T K[:tau])^{-1} q_tau for all tau, chunk-parallel.

    Only uses: one d x d Cholesky, one C x C Cholesky, two C x C triangular
    solves, and matmuls.  Returns X with rows x_tau.
    """
    B = B.astype(dtype); K = K.astype(dtype); Q = Q.astype(dtype)
    C = K.shape[0]
    cb = cho_factor(B, lower=True)
    BiKt = cho_solve(cb, K.T)              # d x C : B^{-1} K^T
    BiQt = cho_solve(cb, Q.T)              # d x C : B^{-1} q_tau (columns)
    A = np.eye(C, dtype=dtype) + K @ BiKt  # C x C, SPD
    L = cholesky(A, lower=True)
    Y = K @ BiQt                           # C x C : column tau = K B^{-1} q_tau
    W = solve_triangular(L, Y, lower=True)
    W = np.triu(W)                         # keep rows i <= tau in column tau
    Z = solve_triangular(L.T, W, lower=False)  # rows > tau come out exactly 0
    X = (BiQt - BiKt @ Z).T
    return X


def direct_nested(B, K, Q):
    C = K.shape[0]
    X = np.zeros_like(Q, dtype=np.float64)
    for t in range(C):
        M = B + K[: t + 1].T @ K[: t + 1]
        X[t] = np.linalg.solve(M, Q[t])
    return X


# ------------------------------------------------- realistic-ish key streams
def make_keys(T, d, alpha=1.0, rho=0.6, rng=rng):
    """Unit-norm keys with an anisotropic spectrum (eigs ~ i^-alpha) and
    AR(1) temporal correlation rho (consecutive tokens look alike)."""
    U, _ = np.linalg.qr(rng.standard_normal((d, d)))
    scale = (np.arange(1, d + 1) ** (-alpha / 2.0))
    z = np.zeros(d)
    out = np.zeros((T, d))
    for t in range(T):
        z = rho * z + np.sqrt(1 - rho ** 2) * rng.standard_normal(d)
        k = U @ (scale * z)
        out[t] = k / np.linalg.norm(k)
    return out


def gates(T, gmean, spread=0.3, rng=rng):
    """Forget gates around gmean (sigmoid-parameterised jitter)."""
    if gmean >= 1.0:
        return np.ones(T)
    logit = np.log(gmean / (1 - gmean)) + spread * rng.standard_normal(T)
    return 1.0 / (1.0 + np.exp(-logit))


# -------------------------------------------------------------- test 1: lemma
def test_lemma():
    print("=== Test 1: nested-inverse lemma vs direct solves ===")
    for d in (64, 128):
        for C in (16, 64):
            errs64, errs32 = [], []
            for trial in range(5):
                keys = make_keys(512 + C, d)
                beta = rng.uniform(0.2, 1.0, 512 + C)
                lam = 0.25
                H0 = lam * np.eye(d) + (keys[:512] * beta[:512, None]).T @ keys[:512]
                K = keys[512:] * np.sqrt(beta[512:, None])
                Q = make_keys(C, d)
                Xd = direct_nested(H0, K, Q)
                X64 = nested_solve(H0, K, Q, np.float64)
                X32 = nested_solve(H0, K, Q, np.float32)
                rel = lambda X: np.max(np.linalg.norm(X - Xd, axis=1) / np.linalg.norm(Xd, axis=1))
                errs64.append(rel(X64)); errs32.append(rel(X32))
            print(f"d={d:4d} C={C:3d}  max rel err fp64={max(errs64):.2e}  fp32={max(errs32):.2e}")


if __name__ == "__main__":
    test_lemma()
