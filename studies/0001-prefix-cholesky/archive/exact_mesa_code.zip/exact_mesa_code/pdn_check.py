"""Exactly preconditioned DeltaNet (Tumma et al., Thm 3.1): write keys
k~_t = P_t k_t from the nested identity (Q = K), then the PDN recurrence
S_t = S_{t-1} + (v_t - S_{t-1} k_t) k~_t^T must reproduce exact Mesa (no forgetting)."""
import numpy as np
from mesa_exact import nested_solve, make_keys
rng = np.random.default_rng(5)
d, dv, T, lam = 64, 64, 512, 0.25
keys = make_keys(T, d, rng=rng); qs = make_keys(T, d, rng=rng); vals = rng.standard_normal((T, dv))
for C in (16, 64):
    H = lam * np.eye(d); S = np.zeros((dv, d)); out = np.zeros((T, dv))
    for c in range(0, T, C):
        K = keys[c:c+C]
        Kt = nested_solve(H, K, K)            # exact write keys for the whole chunk
        for i in range(C):                    # PDN recurrence (sequential here for checking)
            t = c + i
            S = S + np.outer(vals[t] - S @ keys[t], Kt[i])
            out[t] = S @ qs[t]
        H = H + K.T @ K
    # exact Mesa reference
    ref = np.zeros((T, dv)); Hr = lam * np.eye(d); G = np.zeros((dv, d))
    for t in range(T):
        Hr += np.outer(keys[t], keys[t]); G += np.outer(vals[t], keys[t])
        ref[t] = G @ np.linalg.solve(Hr, qs[t])
    err = np.max(np.linalg.norm(out - ref, axis=1) / np.linalg.norm(ref, axis=1))
    print(f"C={C}: exactly preconditioned DeltaNet vs exact Mesa, max rel err = {err:.1e}")
